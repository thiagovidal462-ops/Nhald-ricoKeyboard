# Nhaldûrico Keyboard v1.1

Teclado Android independiente para escribir en Nhaldûrico.

La versión anterior podía tener problemas por usar caracteres Unicode en el package Android. Esta versión usa `com.nhaldur.keyboard`.

## Sin PC
Este proyecto incluye GitHub Actions para compilar el APK en la nube. Sube todos los archivos a un repositorio de GitHub, abre **Actions**, ejecuta **Build Nhaldûrico Keyboard APK**, y descarga el artefacto `NhalduricoKeyboard-debug` cuando termine.

package com.nhaldur.keyboard;

import android.inputmethodservice.InputMethodService;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;

public class NhalduricoInputMethodService extends InputMethodService {
    private LinearLayout root;
    @Override public View onCreateInputView() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(6,6,6,6); root.setBackgroundColor(0xFF17151C);
        addRow(new String[]{"Q","W","E","R","T","Y","U","I","O","P"});
        addRow(new String[]{"A","S","D","F","G","H","J","K","L","Ñ"});
        addRow(new String[]{"Z","X","C","V","B","N","M","KH","GH","DH"});
        addRow(new String[]{"SH","TH","Û","Â","Ë","Î","Ô","'","⌫"});
        LinearLayout bottom = new LinearLayout(this); bottom.setOrientation(LinearLayout.HORIZONTAL);
        addButton(bottom,"Nhal",1.2f,v->commit("Nhal")); addButton(bottom,"Espacio",4f,v->commit(" ")); addButton(bottom,"⏎",1.2f,v->sendEnter());
        root.addView(bottom,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f)); return root;
    }
    private void addRow(String[] keys){ LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); for(String key:keys){ final String k=key; addButton(row,k,1f,v->{if(k.equals("⌫")) deleteOne(); else commit(k);}); } root.addView(row,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f)); }
    private void addButton(LinearLayout row,String text,float weight,View.OnClickListener listener){ Button b=new Button(this); b.setText(text); b.setTextSize(14); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setPadding(0,0,0,0); b.setOnClickListener(listener); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.MATCH_PARENT,weight); lp.setMargins(2,2,2,2); row.addView(b,lp); }
    private InputConnection ic(){return getCurrentInputConnection();}
    private void commit(String text){InputConnection c=ic(); if(c!=null)c.commitText(text,1);}
    private void deleteOne(){InputConnection c=ic(); if(c!=null)c.deleteSurroundingText(1,0);}
    private void sendEnter(){InputConnection c=ic(); if(c!=null){c.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,android.view.KeyEvent.KEYCODE_ENTER)); c.sendKeyEvent(new android.view.KeyEvent(android.view.KeyEvent.ACTION_UP,android.view.KeyEvent.KEYCODE_ENTER));}}
}

plugins { id("com.android.application") }
android { namespace = "com.nhaldur.keyboard"; compileSdk = 35; defaultConfig { applicationId = "com.nhaldur.keyboard"; minSdk = 26; targetSdk = 35; versionCode = 11; versionName = "1.1" } }
java { toolchain { languageVersion.set(JavaLanguageVersion.of(17)) } }
